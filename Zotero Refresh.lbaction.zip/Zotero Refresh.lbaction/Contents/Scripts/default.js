// LaunchBar Action Script
function run(argument) {
  
  var zotJson=File.readJSON('~/zotero-LaunchBar/My Library.json');//将其中的路径改为 Zotero 中导出的 json 路径
  var files=[];
  // zotJson= JSON.parse(zotJson)
  var zotLaunch=[];

  var icon="";
  var badge='';
  var len=zotJson.items.length;
  for (let index = 0; index < len; index++) {
      var path="";
      var children=[];
      switch (zotJson.items[index].itemType) {
          case 'book':
              icon='📘';
              break;
          case 'thesis':
              icon='🎓';
              break;
          default:
              icon='📄';
              break;
      };

      children.push({
        title:zotJson.items[index].title,
        icon:icon,
        subtitle:zotJson.items[index].abstractNote,
        url:zotJson.items[index].select
      });
  
//增加附件检索  
      try {
        for (let a = 0; a < zotJson.items[index].attachments.length; a++) {
          var atta=zotJson.items[index].attachments[a];
          if (zotJson.items[index].attachments[a].hasOwnProperty("path")) {
            children.push({
              title:atta.title,
              path:atta.path
            })
          } else if (zotJson.items[index].attachments[a].url.match(/x-devonthink/)!=null) {
            children.push({            
            title:atta.title,
            icon:"com.devon-technologies.think3",
            url:atta.url
            })
          } else{
            children.push({            
              title:atta.title,
              // icon:"com.devon-technologies.think3",
              url:atta.url
              })
          }
        }
      //  path=zotJson.items[index].attachments[0].path;
        // var ii=(i>8)?100:9;
        
    } catch (err) {
        // path="";
    };
//增加笔记检索
  try {
    for (let a = 0; a < zotJson.items[index].notes.length; a++) {
      var note=zotJson.items[index].notes[a];
      if (note!=[]) {
        children.push({
          title:"笔记:",
          label:note.dateModified,
          icon:"✒️",
          subtitle:note.note.replace(/<div data-schema-version=\"8\"><p>/,''),
          url:'zotero://select/library/items/'+note.key
        })
    }
  //  path=zotJson.items[index].attachments[0].path;
    // var ii=(i>8)?100:9;
    
  }
 }
  catch (err) {
    // path="";
  };

    zotLaunch.push({
      title:zotJson.items[index].title,
      //label:zotJson.items[index].citationKey,
      // url: zotJson.items[index].select,
      icon:icon,
      //badge:badge,
      subtitle:zotJson.items[index].abstractNote,
      // action:"open",
      // actionArgument:index.toString(),
      // pathh:path,
      children:children
  })

};

  try {
    File.writeJSON(zotLaunch, '～/zotero-LaunchBar/My Library-LaunchBar.json', { 'prettyPrint' : true });//将其中的路径改为自己需要保存在路径，并将其复制到 Zotero Search 的 Action 中。
  } catch (exception) {
    LaunchBar.alert('Error while writing JSON: ' + exception);
  };

  // LaunchBar.alert(input);
}

