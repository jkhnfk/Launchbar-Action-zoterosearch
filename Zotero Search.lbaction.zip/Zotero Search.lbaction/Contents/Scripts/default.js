function runWithString(input) {

       var zoteroJson=File.readJSON('path');//将 Zotero Refresh 的 Action 的路径复制过来即可。
       var files=[];
       var input=new RegExp(input.replace(/ /i,'.*'),'i');
       var files=zoteroJson.filter(function(obj) {
           if(obj.title.match(input) === null) {
             return false;
           }
           return true;
         });

       return files;
          // LaunchBar.alert(input);return [{ title: 'An argument was passed: ' + argument }];
      
}
